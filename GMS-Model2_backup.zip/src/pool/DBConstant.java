package pool;

public class DBConstant {
public static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
public static final String MYSQL_DRIVER = "";
public static final String MARIADB_DRIVER = "";
public static final String MSSQL_DRIVER = "";
public static final String CONNECTION_URL = "jdbc:oracle:thin:@localhost:1521:xe";
public static final String UID = "chjjh0";
public static final String PWD = "c1c2";
}
