package domain;

public class ProjectTeamBean {
	private String teamId, teamName;
}
