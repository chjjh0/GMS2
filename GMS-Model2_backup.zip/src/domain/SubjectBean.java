package domain;

public class SubjectBean {
	private String subSeq, subName;
}
