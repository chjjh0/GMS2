package domain;

import lombok.Data;

@Data
public class MemberBean {
	private String memId, teamId, name, age, roll, ssn, password, updatePassword, userid, gender, subject;

	@Override
	public String toString() {
		return "회원목록 [memId=" + memId + ", teamId=" + teamId + ", name=" + name + ", age=" + age + ", roll="
				+ roll + ", ssn=" + ssn + ", password=" + password + ", updatePassword=" + updatePassword + ", userid="
				+ userid + ", gender=" + gender + ", subject=" + subject + "]\n";
	}
}