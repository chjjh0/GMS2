package domain;

public class RecordBean {
	private String recordSeq, grade, age;
}
