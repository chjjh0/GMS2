package command;

public interface Order {
	public void execute();
}