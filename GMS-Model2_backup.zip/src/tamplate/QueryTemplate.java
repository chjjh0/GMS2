package tamplate;

import lombok.Data;
import pool.DBConstant;
@Data
public class QueryTemplate {

}
