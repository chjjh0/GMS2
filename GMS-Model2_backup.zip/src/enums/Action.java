package enums;

public enum Action {
	MOVE, JOIN, CREATE, LIST, SEARCH,
	RETRIEVE, COUNT, UPDATE, DELETE, LOGIN
}
