package enums;

public enum Vendor {
	ORACLE,MYSQL,MARIADB,MSSQL
}
