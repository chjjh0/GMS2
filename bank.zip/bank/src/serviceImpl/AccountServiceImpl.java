package serviceImpl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import domain.Account;
import service.AccountService;
public class AccountServiceImpl implements AccountService{

	Account[] arr;
	int count;
	Account account=null;
	
	public AccountServiceImpl () {
		arr = new Account[10];
	}
	@Override
	public void addList(Account account) {
		arr[count] = account; 
		count++;
	}
	@Override
	public Account[] list() {
		return arr;
	}

	@Override
	public int deposit(int restMoney, String money) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int withdraw(int restMoney, String money) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String createRandom(int start, int end) {
		return null;
	}

	@Override
	public Account createAccount(String name, String uid, String upasswd) {
		account = new Account();
		account.setName(name);
		account.setUid(uid);
		account.setUpasswd(upasswd);
		return account;
	}

	@Override
	public String createAccountNum(String random) {
		Random randomAccNo = new Random();
		String accountNo = "";
		for(int i=0;i<3;i++) {
			accountNo += (i>=2) ?
					randomAccNo.nextInt(999)+100 + "" :
					randomAccNo.nextInt(999)+100 + "-";
		}
		account.setAccountNum(accountNo);
		return account.getAccountNum();
	}

	@Override
	public void createDate() {
		account.setDate(new SimpleDateFormat("yyyy년 MM월 dd일")
	    		.format(new Date()));
	}

	@Override
	public String showResult() {
		String result="";
		for(int i=0;i<count;i++) {
			result += arr[i].toString();
		}
		return result;
	}
}
