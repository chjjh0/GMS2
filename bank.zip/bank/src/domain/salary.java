package domain;

public class salary {

}
