package service;

import domain.Account;

public interface AccountService {
	public void addList(Account account);
	public Account[] list();
	public int deposit(int restMoney, String money);
	public int withdraw(int restMoney, String money);
	public String createRandom(int start, int end);
	public Account createAccount(String name, String uid, String pass);
	public String createAccountNum(String random);
	public void createDate();
	public String showResult();
}
