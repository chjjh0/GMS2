package service;

public interface employeeService {

}
