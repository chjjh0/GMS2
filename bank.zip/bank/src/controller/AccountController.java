package controller;

import javax.swing.JOptionPane;

import domain.*;
import service.*;
import serviceImpl.*;
public class AccountController {
	enum select{EXIT,ACCOUNT,MINUS_ACCOUNT,DEPOSIT,WITHDRAW,LIST};
	public static void main(String[] args) {
		select[] selection = {
                select.EXIT,select.ACCOUNT,select.MINUS_ACCOUNT,
                select.DEPOSIT,select.WITHDRAW,select.LIST
        };
		AccountServiceImpl service= new AccountServiceImpl();
		while(true) {
			select option = (select)JOptionPane.showInputDialog(
                    null,
                    "Choice of Account Type",
                    "Select Menu",
                    JOptionPane.QUESTION_MESSAGE,
                    null, selection, selection[1]);	
		switch(option) {
		case EXIT : return;
		case ACCOUNT :
			Account account = service.createAccount(
					JOptionPane.showInputDialog("이름"),
					JOptionPane.showInputDialog("ID"),
					JOptionPane.showInputDialog("비밀번호"));
			service.addList(account);
			break;
		case MINUS_ACCOUNT :
			break;
		case LIST :
			JOptionPane.showMessageDialog(null, service.showResult());
			break;
		}	
			
		}
	}
}
