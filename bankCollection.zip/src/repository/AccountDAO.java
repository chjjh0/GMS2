package repository;

import java.util.List;

import domain.AccountBean;

public interface AccountDAO {
	public void insertAccount(AccountBean account);
	public List<AccountBean> selectAccount(AccountBean account);
	public List<AccountBean> selectAccountByName(AccountBean account);
	public List<AccountBean> selectAccountById(AccountBean account);
	public void updateAccount(AccountBean account);
	public void deleteAccount(AccountBean account);
}
