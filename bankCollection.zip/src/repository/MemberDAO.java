package repository;

import java.util.List;
import domain.*;
public interface MemberDAO {
	public void insertMember(MemberBean member);
	public List<MemberBean> selectList();
	public List<MemberBean> selectMemberByName(String name);
	public List<MemberBean> selectMemberById(String id);
	public MemberBean login(MemberBean member);
	public int countMembers();
	public int updateMember(MemberBean member);
	public int deleteMember(MemberBean member);
	
}
