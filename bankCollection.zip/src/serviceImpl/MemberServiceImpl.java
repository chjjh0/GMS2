package serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;


import domain.MemberBean;
import domain.StaftBean;
import domain.UserBean;
import repository.MemberDAO;
import repositoryImpl.MemberDAOImpl;
import service.MemberService;

public class MemberServiceImpl implements MemberService{
	Map<String, MemberBean> map;
	public MemberServiceImpl() {
		map = new HashMap<>(); 
	}
	@Override
	public String checkSome(String checkId) {
		String res = "";
		for(String key : map.keySet()) {
			res = (checkId.equals(key)) ? 
					"동일한 ID가 있습니다" :
				    "사용 가능한 ID 입니다";
		}
		return res;
	}
	@Override
	public void createUser(MemberBean member) {
		MemberDAO dao = new MemberDAOImpl();
		System.out.println("맴버 서비스");
		System.out.println("from controller:"+member);
		((UserBean) member).setCreditRating("7등급");
		dao.insertMember(member);
	}
	
	@Override
	public void update(MemberBean member) {
		String id = member.getUid();
		String oldPass = member.getuPasswd().split("/")[0];
		String newPass = member.getuPasswd().split("/")[1];
		MemberBean mem = map.get(id);
		if(mem == null) {
			System.out.println("수정하려는 ID가 없습니다");
		}
		if(oldPass.equals(mem.getuPasswd())) {
			mem.setuPasswd(newPass);
			map.put(id, mem);
		}
	}
	@Override
	public void delete(MemberBean member) {
		map.remove(member.getUid());
	}
	@Override
	public String login(MemberBean member) {
		return null;
	}
}
