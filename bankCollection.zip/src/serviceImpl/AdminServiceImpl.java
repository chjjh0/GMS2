package serviceImpl;
import java.util.*;
import domain.*;
import service.AdminService;
public class AdminServiceImpl implements AdminService{
	List<MemberBean> list;
	
	@Override
	public void createStaft(StaftBean staft) {
		staft.setAccessNum("9999");
		map.put(staft.getUid(), staft);
	}

	@Override
	public List<MemberBean> list() {
		return list;
	}
	
	@Override
	public List<MemberBean> findMemberByName(String param) {
		List<MemberBean> temp = new ArrayList<>();
		for(MemberBean m : list) {
			if(param.equals(m.getName())) {
				temp.put(map.get(key).getUid(), map.get(key));
			}
		}
		return temp;
	}

	@Override
	public List<AccountBean> accountList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AccountBean> findAccountByName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberBean findMemberById(MemberBean member) {
		MemberBean temp = new MemberBean();
		for(MemberBean m : list) {
			if(member.getUid().equals(m.getUid())) {
				temp = m;
				break;
			}
		}
		return temp;
	}

	@Override
	public String createAccountNum() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createDate() {
		// TODO Auto-generated method stub
		return null;
	}
}
	
