package controller;

import javax.swing.JOptionPane;
import domain.*;
import service.*;
import serviceImpl.*;
public class AccountController {
	
	public void account() {
		AccountServiceImpl service = new AccountServiceImpl();
		AccountBean account = new AccountBean();
		account.setName(JOptionPane.showInputDialog("이름"));
		account.setUid(JOptionPane.showInputDialog("ID"));
		account.setUpasswd(JOptionPane.showInputDialog("비밀번호"));
		service.createAccount(account);
	}
	public void minusAccount() {
		AccountServiceImpl service = new AccountServiceImpl();
		AccountBean account = new MinusAccountBean();
		account.setName(JOptionPane.showInputDialog("이름"));
		account.setUid(JOptionPane.showInputDialog("ID"));
		account.setUpasswd(JOptionPane.showInputDialog("비밀번호"));
		service.createMinusAccount(account);
	}
	public void minusList() {
		//JOptionPane.showMessageDialog(null, service.list());
	}
	public void list() {
		//JOptionPane.showMessageDialog(null, service.showResult());
	}
	public void deposit() {
		AccountServiceImpl service = new AccountServiceImpl();
		AccountBean account = new AccountBean();
		account.setUid(JOptionPane.showInputDialog("ID"));
		account.setUpasswd(JOptionPane.showInputDialog("비밀번호"));
		service.deposit(service.authentication(account),
				Integer.parseInt(JOptionPane.showInputDialog("입금액을 입력하세요")));
	}
	public void withdraw() {
		AccountServiceImpl service = new AccountServiceImpl();
		AccountBean account = new AccountBean();
		account.setUid(JOptionPane.showInputDialog("ID"));
		account.setUpasswd(JOptionPane.showInputDialog("비밀번호"));
		service.withdraw(service.authentication(account), 
				Integer.parseInt(JOptionPane.showInputDialog("출금액을 입력하세요")));
	}
	public void findByName() {
		//JOptionPane.showMessageDialog(null, service.findByName(JOptionPane.showInputDialog("이름")));
	}
	public void findById() {
		/*int temp;
		while(true) {
			account = new AccountBean();
			account.setUid(JOptionPane.showInputDialog("ID"));
			account.setUpasswd(JOptionPane.showInputDialog("비밀번호")+"/"+
					JOptionPane.showInputDialog("new 비밀번호"));
			temp = service.authentication(account);
			if(temp!=9999) {
				break;
			} else {
				JOptionPane.showMessageDialog(null, "일치하는 ID가 없습니다");
			}
		}
		while(true) {
			account = new AccountBean();
			account.setUpasswd(JOptionPane.showInputDialog("새로운 비밀번호를 입력하세요"));
			String msg = service.changePass(temp, account);
			if("비밀번호 변경 성공".equals(msg)) {break;}
		}*/
	}
	public static void main(String[] args) {
	}
}