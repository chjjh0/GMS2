package controller;
import javax.swing.JOptionPane;

import domain.*;
import service.*;
import serviceImpl.*;
public class MemberController {
	enum MemberButt {
		EXIT,
		JOIN_USER, JOIN_STEP,
		LIST, FIND_BY_ID, FIND_BY_NAME, COUNT,
		UPDATE,
		REMOVE,
	};
	public void join(MemberBean member) {
		MemberService service = new MemberServiceImpl();
		System.out.println(member);
		service.createUser(member);
	}
	public static void main(String[] args) {
		
		MemberService service = new MemberServiceImpl();
		MemberBean member = null;
		while(true) {
			
		switch((MemberButt)JOptionPane.showInputDialog(
                null,
                "Choice of Account Type",
                "Select Menu",
                JOptionPane.QUESTION_MESSAGE,
                null, new MemberButt[] {MemberButt.EXIT,MemberButt.JOIN_USER,MemberButt.JOIN_STEP, MemberButt.LIST, MemberButt.FIND_BY_ID,
                MemberButt.FIND_BY_NAME,MemberButt.COUNT,MemberButt.UPDATE,MemberButt.REMOVE}, null)) {
		case EXIT : return;
		case JOIN_USER :
			member = new UserBean();
			JOptionPane.showMessageDialog(null, service.checkSome(JOptionPane.showInputDialog("아이디")));
			member.setUid(JOptionPane.showInputDialog("아이디"));
			member.setuPasswd(JOptionPane.showInputDialog("비번"));
			member.setName(JOptionPane.showInputDialog("이름"));
			member.setEmail(JOptionPane.showInputDialog("이메일"));
			member.setAddr(JOptionPane.showInputDialog("주소"));
			member.setPhone(JOptionPane.showInputDialog("전화번호"));
			service.createUser((UserBean)member);
			break;
		case JOIN_STEP :
			member = new StaftBean();
			member.setUid(JOptionPane.showInputDialog("아이디"));
			member.setuPasswd(JOptionPane.showInputDialog("비번"));
			member.setName(JOptionPane.showInputDialog("이름"));
			member.setEmail(JOptionPane.showInputDialog("이메일"));
			member.setAddr(JOptionPane.showInputDialog("주소"));
			member.setPhone(JOptionPane.showInputDialog("전화번호"));
			//service.createStep((StaftBean)member);
			break;
		case LIST :
			//JOptionPane.showMessageDialog(null, service.list()+"\n");
			break;
		case FIND_BY_ID :
			member = new MemberBean();
			member.setUid(JOptionPane.showInputDialog("아이디"));
			//JOptionPane.showMessageDialog(null, service.findById(member));
			break;
		case FIND_BY_NAME :
			//JOptionPane.showMessageDialog(null, service.findByName(JOptionPane.showInputDialog("이름")));
			break;
		case COUNT :
			break;
		case UPDATE :
			member = new MemberBean();
			member.setUid(JOptionPane.showInputDialog("아이디"));
			member.setuPasswd(JOptionPane.showInputDialog("기존비번/새로운비번"));
			service.update(member);
			break;
		case REMOVE :
			member = new MemberBean();
			member.setUid(JOptionPane.showInputDialog("아이디"));
			member.setuPasswd(JOptionPane.showInputDialog("비번"));
			service.delete(member);
			break;
		default:
			break;
		}	
			
		}
	}

}
