package view;

import javax.swing.*;
public class CreateTextField {
	JTextField idTxt;
	JPanel idpan;
	
	public CreateTextField() {
		idTxt = new JTextField();
		idpan = new JPanel();
		idpan.add(idTxt);
	}
}
