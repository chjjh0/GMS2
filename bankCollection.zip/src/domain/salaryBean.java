package domain;

public class salaryBean {

}
