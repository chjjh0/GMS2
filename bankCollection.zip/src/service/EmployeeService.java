package service;

public interface EmployeeService {

}
