package service;

import java.util.List;

import domain.*;

public interface AdminService {
	public void createStaft(StaftBean staft);
	public List<MemberBean> list();
	public List<MemberBean> findMemberByName(String param);
	public List<AccountBean> accountList();
	public List<AccountBean> findAccountByName();
	public MemberBean findMemberById(MemberBean member);
	public String createAccountNum();
	public String createDate();
	/*public Map<String, MemberBean> list();
	public Map<String, MemberBean> findByName(String name);*/
}
