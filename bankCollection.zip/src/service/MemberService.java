package service;
import java.util.List;

import domain.MemberBean;
import domain.StaftBean;
import domain.UserBean;
public interface MemberService {
	public String checkSome(String some);
	public void createUser(MemberBean member);
	public String login(MemberBean member);
	public void update(MemberBean member);
	public void delete(MemberBean member);
}
