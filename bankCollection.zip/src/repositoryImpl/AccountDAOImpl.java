package repositoryImpl;

import java.util.List;

import domain.AccountBean;
import repository.AccountDAO;

public class AccountDAOImpl implements AccountDAO{

	@Override
	public void insertAccount(AccountBean account) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<AccountBean> selectAccount(AccountBean account) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AccountBean> selectAccountByName(AccountBean account) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AccountBean> selectAccountById(AccountBean account) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAccount(AccountBean account) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAccount(AccountBean account) {
		// TODO Auto-generated method stub
		
	}

}
